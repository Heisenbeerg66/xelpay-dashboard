# XelPay Payment Gateway — WordPress / WooCommerce Plugin

**Version:** 1.0.0  
**Requires:** WordPress 5.8+, WooCommerce 6.0+, PHP 7.4+, HTTPS (SSL)

---

## কীভাবে কাজ করে (Flow)

```
Customer "Place Order" করে
        ↓
Plugin → POST /api/create-order (Authorization: Bearer xp_sec_...)
        ↓
XelPay payment_url পাঠায়
        ↓
Customer XelPay payment page এ যায়
        ↓
Customer বিকাশ/নগদ/ব্যাংক/USDT দিয়ে pay করে
        ↓
XelPay → Webhook → POST /wc-api/xelpay_webhook
(X-XelPay-Signature header এ HMAC-SHA256 sign)
        ↓
Plugin signature verify করে → WC Order "Processing" ✅
        ↓
Customer WooCommerce Thank You page এ ফিরে আসে
```

---

## XelPay Dashboard এ আপনি ৩টি Key পাবেন

| Key | কোথায় ব্যবহার হয় | Plugin Field |
|---|---|---|
| **Public Key** (`xp_pub_...`) | Reference only — API call এ লাগে না | Public Key |
| **Secret Key** (`xp_sec_...`) | `Authorization: Bearer` header — সব API call এ | Secret Key |
| **Webhook Signing Secret** (`whsec_...`) | Webhook HMAC-SHA256 verification | Webhook Signing Secret |

---

## Installation

### Step 1 — Plugin Upload করুন

1. WordPress Admin → **Plugins → Add New → Upload Plugin**
2. `xelpay-gateway.zip` select করুন
3. **Install Now** → **Activate Plugin**

---

### Step 2 — Gateway Configure করুন

**WooCommerce → Settings → Payments → XelPay → Manage**

| Field | কী দিবেন |
|---|---|
| **Enable** | ✅ Check করুন |
| **Title** | Checkout এ কাস্টমার যা দেখবে — যেমন: `XelPay (bKash, Nagad & more)` |
| **Description** | Checkout এ ছোট description |
| **XelPay Site URL** | আপনার XelPay এর domain — যেমন: `https://pay.yourdomain.com` |
| **Public Key** | Dashboard থেকে `xp_pub_...` key (শুধু reference এর জন্য) |
| **Secret Key** | Dashboard থেকে `xp_sec_...` key — **এটা দিয়ে API authenticate হয়** |
| **Webhook Signing Secret** | Dashboard থেকে `whsec_...` key — **এটা দিয়ে webhook verify হয়** |

**Save changes** করুন।

---

### Step 3 — Webhook Setup করুন (গুরুত্বপূর্ণ!)

Plugin install করলে Settings page এই URL টা automatically দেখাবে:

```
https://yourstore.com/wc-api/xelpay_webhook
```

**XelPay Dashboard → API & Plugins → Webhook URL** তে এই URL টা দিন।

> ⚠️ যদি আপনার store URL ভিন্ন হয় তাহলে `yourstore.com` এর জায়গায় আপনার actual domain দিন।

---

### Step 4 — Test করুন

1. WooCommerce এ একটা test product যোগ করুন
2. Checkout এ যান → **XelPay** select করুন → **Place Order**
3. XelPay payment page এ redirect হবে
4. Payment করলে webhook আসবে, order `Processing` হবে

---

## Security

| Feature | Details |
|---|---|
| **HMAC-SHA256 Webhook Verify** | XelPay যে `X-XelPay-Signature` header পাঠায় সেটা `whsec_` key দিয়ে verify হয় |
| **Constant-time comparison** | `hash_equals()` ব্যবহার — timing attack proof |
| **Secret key masked** | Admin panel এ key কখনো plain text দেখায় না |
| **Blank = keep existing** | Password field blank রাখলে পুরনো key মুছে যায় না |
| **SSL enforced** | সব API request এ `sslverify: true` |
| **Idempotent webhook** | একই payment এর duplicate webhook safely ignore হয় |
| **Input sanitize** | সব input `sanitize_text_field()` দিয়ে clean |
| **No direct DB query** | সব WooCommerce API দিয়ে |
| **HPOS compatible** | WooCommerce High-Performance Order Storage support |

---

## Order Status Mapping

| XelPay Event | WooCommerce Order Status |
|---|---|
| `payment.success` | **Processing** ✅ |
| `payment.canceled` | **Cancelled** ❌ |

---

## Debug / Troubleshooting

Plugin Settings এ **Debug Log** enable করুন, তারপর দেখুন:

**WooCommerce → Status → Logs → xelpay**

| সমস্যা | সমাধান |
|---|---|
| "Configuration error" | Secret Key এবং XelPay URL দুটোই দিন |
| Webhook আসছে না | XelPay Dashboard এ webhook URL সঠিক আছে কিনা দেখুন |
| Order update হচ্ছে না | Webhook Signing Secret match করছে কিনা দেখুন |
| SSL error | XelPay URL এ valid HTTPS certificate আছে কিনা দেখুন |
| 401 Webhook error | `whsec_` key XelPay Dashboard এর সাথে exact match করছে কিনা দেখুন |

---

## Webhook Manual Test (curl)

```bash
# আপনার values দিন
STORE_URL="https://yourstore.com"
SECRET="whsec_your_webhook_signing_secret"
ORDER_ID="WC-45-1711000000"

# Payload তৈরি
BODY=$(printf '{"event":"payment.success","order_id":"%s","amount":"1500","trx_id":"TXN123456","payment_method":"bkash_personal"}' "$ORDER_ID")

# Signature generate
SIG=$(echo -n "$BODY" | openssl dgst -sha256 -hmac "$SECRET" | awk '{print $2}')

# Webhook পাঠান
curl -X POST "${STORE_URL}/wc-api/xelpay_webhook" \
  -H "Content-Type: application/json" \
  -H "X-XelPay-Signature: ${SIG}" \
  -d "$BODY"
```

**Expected response:**
```json
{"success":true,"message":"Order marked as paid."}
```

---

## Plugin Structure

```
xelpay-gateway/
├── xelpay-gateway.php                  ← Plugin bootstrap
├── includes/
│   ├── class-xelpay-gateway.php        ← WooCommerce payment gateway
│   └── class-xelpay-webhook.php        ← Webhook receiver & verifier
├── assets/
│   ├── css/checkout.css                ← Checkout page styling
│   └── images/xelpay-logo.svg          ← Checkout logo
└── README.md                           ← এই file
```

---

## Frequently Asked Questions

**Q: Public Key কি লাগবে?**  
A: না, API call এ লাগে না। শুধু record রাখার জন্য।

**Q: Secret Key হারিয়ে গেলে?**  
A: XelPay Dashboard থেকে Roll করুন, নতুন key plugin এ আবার দিন।

**Q: Webhook Secret মিলছে না?**  
A: XelPay Dashboard এর exact value copy করুন। Extra space বা line break থাকলে কাজ করবে না।

**Q: একাধিক store এ কি ব্যবহার করা যাবে?**  
A: হ্যাঁ, কিন্তু প্রতিটা store এর জন্য আলাদা webhook URL XelPay Dashboard এ add করতে হবে।

---

## License

GPL-2.0+  © XelPay
