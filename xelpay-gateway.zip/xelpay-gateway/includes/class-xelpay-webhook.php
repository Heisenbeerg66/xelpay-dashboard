<?php
defined( 'ABSPATH' ) || exit;

/**
 * XelPay_Webhook
 *
 * Listens on: POST https://yourstore.com/wc-api/xelpay_webhook
 *
 * XelPay (payment-actions.ts) sends:
 *   Header:  X-XelPay-Signature: <hex_hmac_sha256>
 *   Body:    JSON with event, order_id, amount, trx_id, payment_method
 *
 * We verify the signature using the webhook_secret (whsec_...) and update
 * the WooCommerce order accordingly.
 *
 * Events handled:
 *   payment.success  → mark order as Processing
 *   payment.canceled → mark order as Cancelled
 *   (anything else)  → 422 ignored gracefully
 */
class XelPay_Webhook {

    public static function init(): void {
        add_action( 'woocommerce_api_xelpay_webhook', [ self::class, 'handle' ] );
    }

    // ── Entry Point ───────────────────────────────────────────────────────────

    public static function handle(): void {
        // Read raw body BEFORE any framework parsing
        $raw_body = file_get_contents( 'php://input' );

        // ── Security: verify HMAC-SHA256 signature ───────────────────────────
        // XelPay sends: X-XelPay-Signature: <hex_digest>
        // (see sendSuccessNotifications / sendCancelNotifications in payment-actions.ts)
        $signature = $_SERVER['HTTP_X_XELPAY_SIGNATURE'] ?? '';

        if ( ! self::verify_signature( $raw_body, $signature ) ) {
            self::respond( 401, [ 'success' => false, 'message' => 'Invalid or missing signature.' ] );
            return;
        }

        // ── Parse JSON ────────────────────────────────────────────────────────
        $payload = json_decode( $raw_body, true );

        if ( ! is_array( $payload ) ) {
            self::respond( 400, [ 'success' => false, 'message' => 'Invalid JSON.' ] );
            return;
        }

        $event      = sanitize_text_field( $payload['event']          ?? '' );
        $order_id   = sanitize_text_field( $payload['order_id']       ?? '' );
        $amount     = floatval( $payload['amount']                    ?? 0 );
        $trx_id     = sanitize_text_field( $payload['trx_id']         ?? '' );
        $method     = sanitize_text_field( $payload['payment_method'] ?? '' );

        if ( empty( $event ) || empty( $order_id ) ) {
            self::respond( 400, [ 'success' => false, 'message' => 'Missing event or order_id.' ] );
            return;
        }

        self::get_gateway()->log(
            "Webhook received: event={$event} order={$order_id} trx={$trx_id}",
            'info'
        );

        // ── Route by event ────────────────────────────────────────────────────
        switch ( $event ) {
            case 'payment.success':
                self::handle_success( $order_id, $trx_id, $amount, $method );
                break;

            case 'payment.canceled':
                self::handle_cancelled( $order_id );
                break;

            default:
                // Unknown event — log and acknowledge (don't retry)
                self::get_gateway()->log( "Unknown webhook event: {$event}", 'warning' );
                self::respond( 200, [ 'success' => true, 'message' => 'Event ignored.' ] );
        }
    }

    // ── Event Handlers ────────────────────────────────────────────────────────

    private static function handle_success(
        string $xelpay_order_id,
        string $trx_id,
        float  $amount,
        string $method
    ): void {
        $order = self::find_order( $xelpay_order_id );

        if ( ! $order ) {
            self::respond( 404, [ 'success' => false, 'message' => 'WC order not found.' ] );
            return;
        }

        // Idempotency: ignore if already paid
        if ( $order->is_paid() ) {
            self::respond( 200, [ 'success' => true, 'message' => 'Already paid — ignored.' ] );
            return;
        }

        // Mark payment complete (triggers WooCommerce stock reduction, emails, etc.)
        $order->payment_complete( $trx_id ?: $xelpay_order_id );

        $order->add_order_note( sprintf(
            'XelPay payment confirmed. Method: %s | TrxID: %s | Amount: %s',
            esc_html( $method ),
            esc_html( $trx_id ),
            wc_price( $amount )
        ) );

        if ( $trx_id ) {
            $order->update_meta_data( '_xelpay_trx_id',     $trx_id );
            $order->update_meta_data( '_xelpay_method',     $method );
        }
        $order->save();

        self::get_gateway()->log( "Order #{$order->get_id()} marked PAID via {$method} TrxID={$trx_id}" );
        self::respond( 200, [ 'success' => true, 'message' => 'Order marked as paid.' ] );
    }

    private static function handle_cancelled( string $xelpay_order_id ): void {
        $order = self::find_order( $xelpay_order_id );

        if ( ! $order ) {
            self::respond( 404, [ 'success' => false, 'message' => 'WC order not found.' ] );
            return;
        }

        if ( in_array( $order->get_status(), [ 'cancelled', 'processing', 'completed' ], true ) ) {
            self::respond( 200, [ 'success' => true, 'message' => 'Status unchanged.' ] );
            return;
        }

        $order->update_status( 'cancelled', 'XelPay: payment cancelled by customer.' );
        self::get_gateway()->log( "Order #{$order->get_id()} marked CANCELLED." );
        self::respond( 200, [ 'success' => true, 'message' => 'Order cancelled.' ] );
    }

    // ── Signature Verification ────────────────────────────────────────────────

    /**
     * Verify HMAC-SHA256 signature.
     *
     * XelPay (payment-actions.ts) builds:
     *   const signature = crypto.createHmac('sha256', webhookSecret)
     *                           .update(payloadStr).digest('hex');
     * and sends it in X-XelPay-Signature header.
     *
     * We replicate the same computation and compare with hash_equals()
     * to prevent timing attacks.
     */
    private static function verify_signature( string $raw_body, string $received_sig ): bool {
        $secret = self::get_webhook_secret();

        if ( empty( $secret ) || empty( $received_sig ) ) {
            self::get_gateway()->log( 'Webhook verification failed: missing secret or signature.', 'error' );
            return false;
        }

        $expected = hash_hmac( 'sha256', $raw_body, $secret );

        // hash_equals() is constant-time — prevents timing attacks
        return hash_equals( $expected, $received_sig );
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    /**
     * Find the WooCommerce order that has _xelpay_order_id = $xelpay_order_id.
     */
    private static function find_order( string $xelpay_order_id ): ?WC_Order {
        $orders = wc_get_orders( [
            'meta_key'   => '_xelpay_order_id',
            'meta_value' => $xelpay_order_id,
            'limit'      => 1,
        ] );
        return ! empty( $orders ) ? $orders[0] : null;
    }

    /**
     * Get the instantiated gateway (for config and logging).
     */
    private static function get_gateway(): WC_XelPay_Gateway {
        static $instance;
        if ( ! $instance ) {
            $gateways = WC()->payment_gateways()->payment_gateways();
            $instance = $gateways['xelpay'] ?? new WC_XelPay_Gateway();
        }
        return $instance;
    }

    private static function get_webhook_secret(): string {
        return self::get_gateway()->get_webhook_secret();
    }

    /**
     * Send JSON response and exit.
     */
    private static function respond( int $http_code, array $body ): void {
        status_header( $http_code );
        header( 'Content-Type: application/json; charset=utf-8' );
        echo wp_json_encode( $body );
        exit;
    }
}
