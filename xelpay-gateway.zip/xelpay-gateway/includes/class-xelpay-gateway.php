<?php
defined( 'ABSPATH' ) || exit;

/**
 * WC_XelPay_Gateway
 *
 * Integrates XelPay with WooCommerce checkout.
 *
 * Flow:
 *   1. Customer places order → process_payment() calls POST /api/create-order
 *      with Bearer {secret_key} header
 *   2. XelPay returns payment_url  → customer redirected to XelPay payment page
 *   3. Customer pays on XelPay     → XelPay fires webhook to /wc-api/xelpay_webhook
 *   4. Webhook verifies HMAC sig using webhook_secret → updates WC order status
 *
 * Keys used:
 *   secret_key      → API authentication (Bearer token in Authorization header)
 *   webhook_secret  → HMAC-SHA256 webhook signature verification
 *   public_key      → Displayed for reference; not used server-side
 */
class WC_XelPay_Gateway extends WC_Payment_Gateway {

    /** @var string */
    private string $xelpay_url;

    /** @var string Bearer token for API calls */
    private string $secret_key;

    /** @var string HMAC key for webhook verification */
    private string $webhook_secret;

    /** @var string Informational only */
    private string $public_key;

    /** @var bool */
    private bool $debug;

    public function __construct() {
        $this->id                 = 'xelpay';
        $this->icon               = XELPAY_PLUGIN_URL . 'assets/images/xelpay-logo.svg';
        $this->has_fields         = false;
        $this->method_title       = 'XelPay';
        $this->method_description = 'Accept payments via bKash, Nagad, Rocket, Bank, USDT, Binance Pay & more through XelPay.';
        $this->supports           = [ 'products' ];

        $this->init_form_fields();
        $this->init_settings();

        $this->title          = $this->get_option( 'title' );
        $this->description    = $this->get_option( 'description' );
        $this->xelpay_url     = rtrim( $this->get_option( 'xelpay_url', '' ), '/' );
        $this->public_key     = $this->get_option( 'public_key', '' );
        $this->secret_key     = $this->get_option( 'secret_key', '' );
        $this->webhook_secret = $this->get_option( 'webhook_secret', '' );
        $this->debug          = 'yes' === $this->get_option( 'debug', 'no' );

        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            [ $this, 'process_admin_options' ]
        );

        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_checkout_styles' ] );
    }

    // ── Admin Settings ────────────────────────────────────────────────────────

    public function init_form_fields(): void {
        $webhook_url = home_url( '/wc-api/xelpay_webhook' );

        $this->form_fields = [

            'enabled' => [
                'title'   => 'Enable / Disable',
                'type'    => 'checkbox',
                'label'   => 'Enable XelPay Payment Gateway',
                'default' => 'no',
            ],

            'title' => [
                'title'       => 'Title',
                'type'        => 'text',
                'description' => 'Label shown to the customer at checkout.',
                'default'     => 'XelPay (bKash, Nagad, Rocket & more)',
                'desc_tip'    => true,
            ],

            'description' => [
                'title'   => 'Description',
                'type'    => 'textarea',
                'default' => 'Pay securely using bKash, Nagad, Rocket, Bank Transfer, USDT, Binance Pay and more via XelPay.',
            ],

            'credentials_section' => [
                'title'       => 'API Credentials',
                'type'        => 'title',
                'description' => 'Copy these values from your XelPay Dashboard → API & Plugins.',
            ],

            'xelpay_url' => [
                'title'       => 'XelPay Site URL',
                'type'        => 'text',
                'description' => 'The root URL of your XelPay deployment. Example: <code>https://pay.yourdomain.com</code>',
                'default'     => '',
                'placeholder' => 'https://pay.yourdomain.com',
            ],

            'public_key' => [
                'title'       => 'Public Key (Publishable)',
                'type'        => 'text',
                'description' => 'Starts with <code>xp_pub_</code>. Stored for reference — not used in API calls.',
                'default'     => '',
                'placeholder' => 'xp_pub_...',
                'desc_tip'    => true,
            ],

            'secret_key' => [
                'title'       => 'Secret Key (Hidden)',
                'type'        => 'password',
                'description' => 'Starts with <code>xp_sec_</code>. Used as the <code>Authorization: Bearer</code> token in all API requests. <strong>Never share this.</strong>',
                'default'     => '',
                'placeholder' => 'xp_sec_...',
                'custom_attributes' => [ 'autocomplete' => 'new-password' ],
            ],

            'webhook_section' => [
                'title'       => 'Webhook Settings',
                'type'        => 'title',
                'description' => sprintf(
                    'Add this URL in your XelPay Dashboard → API & Plugins → Webhook URL:<br/><code style="background:#f0f0f0;padding:6px 12px;border-radius:6px;display:inline-block;margin-top:6px;font-size:13px;">%s</code>',
                    esc_url( $webhook_url )
                ),
            ],

            'webhook_secret' => [
                'title'       => 'Webhook Signing Secret',
                'type'        => 'password',
                'description' => 'Starts with <code>whsec_</code>. Must match the Webhook Signing Secret in your XelPay Dashboard. Used to verify every incoming webhook using HMAC-SHA256.',
                'default'     => '',
                'placeholder' => 'whsec_...',
                'custom_attributes' => [ 'autocomplete' => 'new-password' ],
            ],

            'debug_section' => [
                'title' => 'Advanced',
                'type'  => 'title',
            ],

            'debug' => [
                'title'       => 'Debug Log',
                'type'        => 'checkbox',
                'label'       => 'Enable debug logging (WooCommerce → Status → Logs → xelpay)',
                'default'     => 'no',
                'description' => 'Only enable this for troubleshooting.',
            ],

        ];
    }

    /**
     * Override save: if password fields are submitted blank, keep existing values.
     */
    public function process_admin_options(): bool {
        $old_secret  = $this->get_option( 'secret_key' );
        $old_webhook = $this->get_option( 'webhook_secret' );

        $result = parent::process_admin_options();

        foreach ( [ 'secret_key' => $old_secret, 'webhook_secret' => $old_webhook ] as $field => $old_val ) {
            $posted = isset( $_POST[ $this->get_field_key( $field ) ] )
                ? sanitize_text_field( wp_unslash( $_POST[ $this->get_field_key( $field ) ] ) )
                : '';
            if ( empty( $posted ) && ! empty( $old_val ) ) {
                $this->update_option( $field, $old_val );
            }
        }

        return $result;
    }

    // ── Checkout ──────────────────────────────────────────────────────────────

    public function enqueue_checkout_styles(): void {
        if ( ! is_checkout() ) return;
        wp_enqueue_style(
            'xelpay-checkout',
            XELPAY_PLUGIN_URL . 'assets/css/checkout.css',
            [],
            XELPAY_VERSION
        );
    }

    // ── Process Payment ───────────────────────────────────────────────────────

    /**
     * Called by WooCommerce when the customer clicks "Place Order".
     *
     * Sends POST /api/create-order to XelPay with Bearer token.
     * XelPay API response contains payment_url → we redirect customer there.
     */
    public function process_payment( $order_id ): array {
        $order = wc_get_order( $order_id );

        if ( ! $order ) {
            wc_add_notice( 'Order not found.', 'error' );
            return [ 'result' => 'failure' ];
        }

        // Validate config
        if ( empty( $this->xelpay_url ) || empty( $this->secret_key ) ) {
            $this->log( 'XelPay is not configured: missing URL or secret key.', 'error' );
            wc_add_notice( 'Payment gateway configuration error. Please contact the store owner.', 'error' );
            return [ 'result' => 'failure' ];
        }

        // Unique order ID for XelPay — prefix with WC so it's identifiable
        $xelpay_order_id = 'WC-' . $order->get_id() . '-' . time();

        $payload = [
            'order_id'       => $xelpay_order_id,
            'amount'         => number_format( (float) $order->get_total(), 2, '.', '' ),
            'currency'       => get_woocommerce_currency(),
            'product_name'   => $this->build_product_summary( $order ),
            'customer_name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
            'customer_email' => $order->get_billing_email(),
            'customer_phone' => $order->get_billing_phone(),
            'redirect_url'   => $this->get_return_url( $order ),   // WC thank-you page
        ];

        $response = $this->api_post( '/api/create-order', $payload );

        if ( is_wp_error( $response ) ) {
            $this->log( 'API error: ' . $response->get_error_message(), 'error' );
            wc_add_notice( 'Could not connect to XelPay. Please try again or choose another payment method.', 'error' );
            return [ 'result' => 'failure' ];
        }

        // XelPay returns { success: true, payment_url: "...", order_id: "..." }
        if ( empty( $response['success'] ) || empty( $response['payment_url'] ) ) {
            $msg = $response['message'] ?? 'Unexpected response from XelPay.';
            $this->log( 'API returned error: ' . $msg, 'error' );
            wc_add_notice( esc_html( $msg ), 'error' );
            return [ 'result' => 'failure' ];
        }

        // Persist XelPay order ID so webhook can look up this WC order
        $order->update_meta_data( '_xelpay_order_id',    $xelpay_order_id );
        $order->update_meta_data( '_xelpay_payment_url', $response['payment_url'] );
        $order->add_order_note( sprintf(
            'XelPay: payment initiated. XelPay Order ID: %s',
            $xelpay_order_id
        ) );
        $order->save();

        $this->log( "Order #{$order->get_id()} → XelPay {$xelpay_order_id} — redirecting to payment page." );

        return [
            'result'   => 'success',
            'redirect' => $response['payment_url'],
        ];
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * POST to XelPay API with Bearer token authentication.
     *
     * Matches the API route:
     *   Authorization: Bearer {secret_key}
     *   Content-Type:  application/json
     */
    private function api_post( string $endpoint, array $body ): array|\WP_Error {
        $url = $this->xelpay_url . $endpoint;

        $response = wp_remote_post( $url, [
            'timeout'   => 30,
            'sslverify' => true,
            'headers'   => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $this->secret_key,
                'X-Source'      => 'woocommerce/' . XELPAY_VERSION,
            ],
            'body' => wp_json_encode( $body ),
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $http_code = wp_remote_retrieve_response_code( $response );
        $data      = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! is_array( $data ) ) {
            return new \WP_Error( 'xelpay_parse', "XelPay returned non-JSON (HTTP {$http_code})." );
        }

        return $data;
    }

    /**
     * Summarise order items into a product_name string.
     */
    private function build_product_summary( WC_Order $order ): string {
        $names = array_map( fn( $item ) => $item->get_name(), array_values( $order->get_items() ) );
        if ( empty( $names ) ) return 'WooCommerce Order';
        $summary = implode( ', ', array_slice( $names, 0, 3 ) );
        if ( count( $names ) > 3 ) $summary .= ' & ' . ( count( $names ) - 3 ) . ' more';
        return $summary;
    }

    /**
     * WooCommerce logger wrapper — respects debug toggle.
     */
    public function log( string $message, string $level = 'info' ): void {
        if ( ! $this->debug && $level === 'info' ) return;
        wc_get_logger()->log( $level, $message, [ 'source' => 'xelpay' ] );
    }

    /**
     * Expose webhook_secret so the Webhook class can read it.
     */
    public function get_webhook_secret(): string {
        return $this->webhook_secret;
    }
}
