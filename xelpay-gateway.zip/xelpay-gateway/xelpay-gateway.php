<?php
/**
 * Plugin Name:       XelPay Payment Gateway
 * Plugin URI:        https://xelpay.com
 * Description:       Accept payments via XelPay — bKash, Nagad, Rocket, Bank, USDT, Binance Pay & more. Full WooCommerce integration with HMAC-signed webhooks.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            XelPay
 * Author URI:        https://xelpay.com
 * License:           GPL-2.0+
 * Text Domain:       xelpay-gateway
 * WC requires at least: 6.0
 * WC tested up to:   8.9
 */

defined( 'ABSPATH' ) || exit;

// ── Constants ─────────────────────────────────────────────────────────────────
define( 'XELPAY_VERSION',     '1.0.0' );
define( 'XELPAY_PLUGIN_FILE', __FILE__ );
define( 'XELPAY_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'XELPAY_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

// ── WooCommerce HPOS Compatibility ───────────────────────────────────────────
add_action( 'before_woocommerce_init', function () {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables', __FILE__, true
        );
    }
} );

// ── Boot after all plugins loaded ────────────────────────────────────────────
add_action( 'plugins_loaded', function () {

    // WooCommerce must be active
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="error"><p>'
                . '<strong>XelPay Gateway</strong> requires WooCommerce to be installed and active.'
                . '</p></div>';
        } );
        return;
    }

    require_once XELPAY_PLUGIN_DIR . 'includes/class-xelpay-gateway.php';
    require_once XELPAY_PLUGIN_DIR . 'includes/class-xelpay-webhook.php';

    // Register gateway
    add_filter( 'woocommerce_payment_gateways', function ( $gateways ) {
        $gateways[] = 'WC_XelPay_Gateway';
        return $gateways;
    } );

    // Boot webhook listener
    XelPay_Webhook::init();

} );

// ── Activation / Deactivation ─────────────────────────────────────────────────
register_activation_hook( __FILE__, function () {
    flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, function () {
    flush_rewrite_rules();
} );
